This 'elsarticle.cls' file is used to handle error:


! LaTeX Error: Mismatched LaTeX support files detected.
(LaTeX) Loading 'expl3.sty' aborted!
(LaTeX) The L3 programming layer in the LaTeX format is dated 2022-10-26, but in your TeX tree the files
require at least 2023-02-22.

